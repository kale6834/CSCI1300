#include "Gameplay.h"
#include "Supplies.h"
#include "Players.h"

Gameplay::Gameplay()
{
    numMoney = 1200.00;
    totalBill = 0;
}

// int randomNumbers2(int min, int max){
//     // rand() % (max-min+1) + min
//     return (rand() % (max-min+1)) + min;
// }

// int main(){
//     int num = 0;
//     // need to write before calling rand() to seed the random number generator
//     srand(time(0));
    
//     for(int i=0;i<10;++i)
//     {
//         // random numbers between 3 and 10
//         num = randomNumbers2(1,3);
//         cout<<num<<" ";
//     }
// }

void Gameplay::addPlayers (string username) //adds user the database
{
    int numPlayers = 0;
    while (numPlayers <= 5)
    {
        players[numPlayers].setUsername(username); //set the username to lowercase
        numPlayers++;
    }
}

int Gameplay::buyOxen(int numItems)
{
    int OxenCounter = numItems;
    totalBill = (numItems * 2) + totalBill;
    if (totalBill > numMoney)
    {
        cout << "You do not have enough money. Please choose another amount" << endl;
    }
    else
    {
        supplies[OxenCounter].setNumOxen(numItems);
    }
    cout << "You bought " << supplies[OxenCounter].getNumOxen() << " oxen." << endl;
    return numItems;
}

int Gameplay::buyFood (int numItems)
{
    int FoodCounter = numItems;
    totalBill += totalBill + (numItems * 0.50);
    if (totalBill > numMoney)
    {
        cout << "You do not have enough money. Please choose another amount." << endl;
    }
    else
    {
        numMoney -= totalBill;
        for (int i = 0; i < FoodCounter; i++)
        {
            supplies[FoodCounter].setNumFood(i);
        }
    }
    cout << "You now have " << supplies[FoodCounter].getNumFood() << " in your supply." << endl;
    return numItems;
}

int Gameplay::buyAmmo(int numItems)
{
    int numBullets = 0;
    int AmmoCounter = numItems;
    totalBill += 2 * numItems;
    if (totalBill > numMoney)
    {
        cout << "You do not have enough money. Please choose another amount." << endl;
    }
    else
    {
        for (int i = 0; i < AmmoCounter; i++)
        {
            numBullets = AmmoCounter * 20;
        }
        supplies[AmmoCounter].setNumAmmo(numBullets);
    }
    cout << "You now have " << supplies[AmmoCounter].getNumAmmo() << " in your arsenal." << endl;
    return numItems;
}

int Gameplay::buyWagonParts(int numItems)
{
    int PartCounter = numItems;
    totalBill += (numItems * 20);
    if (totalBill > numMoney)
    {
        cout << "You do not have enough money. Please choose another amount." << endl;
    }
    else
    {
        for (int i = 0; i < PartCounter; i++)
        {
            supplies[PartCounter].setNumWagonParts(i);
        }
        cout << "Would you like to buy more parts?" << endl;
    }
    cout << "You now have " << supplies[PartCounter].getNumWagonParts() << " in your arsenal." << endl;
}

int Gameplay::buyMedKits(int numItems)
{
    int MedKitCounter = numItems;
    totalBill += (numItems * 25);
    if (totalBill > numMoney)
    {
        cout << "You do not have enough money. Please choose another amount." << endl;
    }
    else
    {
        for (int i = 0; i < MedKitCounter; i++)
        {
            supplies[MedKitCounter].setNumMedKits(i);
        }
    }
    cout << "You now have " << supplies[MedKitCounter].getNumMedKits() << " in your aresenal." << endl;
    return numItems;
}

double Gameplay::getTotalBill()
{
    return totalBill;
}

void storeMenu()
{
    cout << "Select which one you would like to buy" << endl;
    cout << "1: Buy oxen" << endl;
    cout << "2: Buy food" << endl;
    cout << "3: Buy ammo" << endl;
    cout << "4: Buy wagon parts" << endl;
    cout << "5: Buy med kits" << endl;
    cout << "6: Print total bill" << endl;
    cout << "7: Exit" << endl;
}
void Gameplay::visitStore() //ask player what kind of supplies they want to buy and store that into the supplies class
{
    string answer;
    Supplies();
    int OxenCounter = 0;
    int FoodCounter = 0;
    int AmmoCounter = 0;
    int MedKitCounter = 0;
    int WagonPartCounter = 0;
    int numBullet = 0;
    int numItems = 0;
    
    cout << "First you will buy your wagon for $200" << endl;
    totalBill = 200.00;
    
    storeMenu();
    
    while (answer != "7")
    {
        getline(cin, answer);
        switch(stoi(answer))
        {
            case 1:
                    cout << "There are two oxen in a yoke. Each yoke cost $40. How many would you like to buy?" << endl;
                    cin >> numItems;
                    buyOxen (numItems);
                    cout << endl;
                    break;
                case 2:
                    cout << "Now you need to buy food. I recommend buying at least 200lb per person. Food cost $0.50 per pound." << endl;
                    cout << "How many pounds of food would you like to buy?" << endl;
                    cin >> numItems;
                    buyFood (numItems);
                    cout << endl;
                    break;
                case 3: 
                
                    cout << "How many boxes of bullet would you like to buy? Remember that 20 bullets are in 1 box." << endl;
                    cin >> numItems;
                    buyAmmo(numItems);
                    cout << endl;
                    break;
                    
                case 4: 
                    cout << "How many wagon parts would you like to buy? This consists of wheels, axles, and tongues." << endl;
                    cin >> numItems;
                    buyWagonParts(numItems);
                    cout << endl;
                    break;
                    
                case 5: 
                    cout << "How many wagon parts would you like to buy?" << endl;
                    cin >> numItems;
                    buyMedKits(numItems);
                    cout << endl;
                    break;
                    
                case 6: 
                    getTotalBill();
                    cout << endl;
                    break;
                    
                case 7: 
                // takeTurns();
                break;
                
                default:
                    cout << "Invalid input" << endl;
        }
    }
    
    
}

// void Gameplay::takeTurns()
// {
//     string choice;
//     cout << "Date: " << players[...].getCurrentDate() << endl;
//     cout << "Miles traveled: " << players[...].getCurrentMiles() << endl;
//     cout << ""
    
//     cout << "You can choose to rest, continue, hunt, or quit." << endl;
//     cout << "1: Rest" << endl;
//     cout << "2: Continue on trail" << endl;
//     cout << "3: Hunt" << endl;
//     cout << "4: Quit" << endl;
    
//     while (choice != "4")
//     {
//         getline(cin, choie);
//         switch(stoi(choice))
//         {
//             case 1:
//                 int num = 0;
//                 // need to write before calling rand() to seed the random number generator
//                 srand(time(0));
                
//                 for(int i=0;i<10;++i)
//                 {
//                     // random numbers between 3 and 10
//                     num = randomNumbers2(1,3);
//                 }
//                     }
//                 }
//                 supplies.foodEaten(num);
//                 cout << "There is " << supplies[FoodCounter].getNumFood() << " left in your wagon." << endl;
//                 cout << endl;
//             case 2:
                
// }

// int Gameplay::rest()
// {
    
// }

//after player leaves the store they will head towards oregon city
//every 20 miles a misfortune might occur (40% chance)
//player can stop at forts along the way but items will cost more
//if all the oxen, main player, or all wagon parts are gone, then the game ends