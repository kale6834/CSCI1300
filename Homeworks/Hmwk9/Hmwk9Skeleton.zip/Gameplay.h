#include <iostream>
#include <string>
#include <time.h>
using namespace std;

#include "Supplies.h"
#include "Players.h"

#ifndef GAMEPLAY_H
#define GAMEPLAY_H



class Gameplay
{
    public:
    
    Gameplay();
    
    void addPlayers (string); //adds the player to the game
    
    int buyOxen(int); //function for buying the oxen
    
    int buyFood(int); //function for buying the food
    
    int buyAmmo(int); //function for buying the bullets
    
    int buyWagonParts(int); //function for buying the wagon parts
     
    int buyMedKits(int); //function for buying the med kits
    
    double getTotalBill(); //function for getting the total bill
    
    void visitStore(); //function for visiting the store and has the switch cases
    
    private:
    double numMoney;
    double totalBill;
    Supplies supplies[1000];
    Players players[1000];
};

#endif