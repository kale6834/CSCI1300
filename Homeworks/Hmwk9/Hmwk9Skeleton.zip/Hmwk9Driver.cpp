#include <iostream>
#include <string>
using namespace std;

#include "Gameplay.h"
//#include "Players.h"
//#include "Supplies.h"

bool endOfGame(Players players[], Supplies supplies[])
{
    bool ended = false;
    //this initiates if the computer or human total is more than or equal to 100
    // if (ComputerTotal >= 100 || HumanTotal >= 100)
    // {
    //     //if the computer total is equal to or greater than 100, the computer wins
    //     if (ComputerTotal >= 100)
    //     {
    //         cout << "Congratulations! computer won this round of jeopardy dice!" << endl;
    //         ended = true;
    //     }
    //     //if the human total is equal to or greater than 100, the human wins
    //     else if (HumanTotal >= 100)
    //     {
    //         cout << "Congratulations! human won this round of jeopardy dice!" << endl;
    //         ended = true;
    //     }
    // }
    return ended;
}

void displayMenu()
{
    cout << "YOU HAD SAVED $1200 TO SPEND FOR THE TRIP, AND YOU'VE JUST PAID $200 FOR A WAGON. YOU WILL NEED TO SPEND THE REST OF YOUR MONEY ON THE FOLLOWING ITEMS:\n"
                   "-OXEN. YOU CAN SPEND $100-$200 ON YOUR TEAM. THE MORE YOU SPEND, THE FASTER YOU'LL GO BECAUSE YOU'LL HAVE BETTER ANIMALS\n"
                   "-FOOD. THE MORE YOU HAVE, THE LESS CHANCE THERE IS OF GETTING SICK\n"
                   "-AMMUNITION - $2 BUYS A BELT OF 20 BULLETS. YOU WILL NEED BULLETS FOR ATTACKS BY ANIMALS AND BANDITS, AND FOR HUNTING FOOD\n"
                   "-MISCELLANEOUS SUPPLIES. THIS INCLUDES MEDICINE AND OTHER THINGS YOU WILL NEED FOR SICKNESS AND EMERGENCY REPAIRS\n"
                   "YOU CAN SPEND ALL YOUR MONEY BEFORE YOU START YOUR TRIP, OR YOU CAN SAVE SOME OF YOUR CASH TO SPEND AT FORTS ALONG THE WAY WHEN YOU RUN LOW. HOWEVER, ITEMS COST MORE AT THE FORTS. YOU CAN ALSO GO HUNTING ALONG THE WAY TO GET MORE FOOD.\n"
                   "\n";
}

int main ()
{
    Gameplay gameplay;
    int numItems = 0;
    string username;
    // while (endOfGame(players, supplies) == false)
    // {
    //     gameplay.addPlayers(username);
    //     displayMenu();
    //     gameplay.visitStore();
        
    // }
    gameplay.visitStore();
    
}