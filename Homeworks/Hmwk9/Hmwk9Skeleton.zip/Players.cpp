#include "Players.h"


Players::Players()
{
    numPlayers = 0;
    player = "";
}

void Players::setUsername(string input)
{
    player = input;
}

string Players::getUsername()
{
    return player;
}

