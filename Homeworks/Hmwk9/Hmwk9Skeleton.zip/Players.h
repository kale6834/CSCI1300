#include <iostream>
#include <string>
using namespace std;


#ifndef PLAYER_H
#define PLAYER_H


class Players
{
    public:
    
    Players(); //defaults private variables to null
    
    string getUsername();
    
    void setUsername(string);
    
    void setCurrentDate (int, int, int);
    
    string getCurrentDate ();
    
    void setCurrentMiles (int);
    
    double getCurrentMiles ();
    
    void setDistanceFromMilestone (int);
    
    double getDistanceFromMilestone ();
    
    void setCashAvailable (int);
    
    int getCashAvailable ();
    
    
    private:
    int numPlayers;
    string player;
};

#endif