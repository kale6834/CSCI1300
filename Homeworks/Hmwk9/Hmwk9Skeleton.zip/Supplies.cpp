#include "Supplies.h"

Supplies::Supplies()
{
    numOxen = 0;
    numFood = 0;
    numAmmo = 0;
    numWagonParts = 0;
    numMedKits = 0;
}

int randomNumbers(int min, int max){
    // rand() % (max-min+1) + min
    return (rand() % (max-min+1)) + min;
}

void Supplies::setNumOxen(int input)
{
    numOxen = input;
}

int Supplies::getNumOxen()
{
    return numOxen;
}

void Supplies::setNumFood(int input)
{
    numFood = input;
}

int Supplies::getNumFood()
{
    return numFood;
}

void Supplies::setNumAmmo(int input)
{
    numAmmo = input;
}

int Supplies::getNumAmmo()
{
    return numAmmo;
}

void Supplies::setNumWagonParts(int input)
{
    numWagonParts = input;
}

int Supplies::getNumWagonParts()
{
    return numWagonParts;
}

void Supplies::setNumMedKits(int input)
{
    numMedKits = input;
}

int Supplies::getNumMedKits()
{
    return numMedKits;
}

int Supplies::foodEaten (int numPlayers)
{
    int num = 0;
    // need to write before calling rand() to seed the random number generator
    srand(time(0));
    
    for(int i=0;i<10;++i)
    {
        // random numbers between 3 and 10
        num = randomNumbers(1,3);
    }
    for (int i = 0; i < numPlayers; i++)
    {
        numFood = numFood - (num * 3);
    }
    return num;
}

