#include <iostream>
#include <string>
using namespace std;

#ifndef DATE_H
#define DATE_H

class Date
{
    //this will keep track of the dates during the player's travels
};

#endif